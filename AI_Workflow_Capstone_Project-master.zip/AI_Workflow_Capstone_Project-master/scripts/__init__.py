from pathlib import Path
ROOT_DIR = Path(__file__).parent.parent
AVAILABLE_COUNTRIES = ['United Kingdom', 'Portugal', 'Germany', 'EIRE', 'France',
                       'Netherlands', 'Spain', 'Norway', 'Hong Kong', 'Singapore', None]

